import React from "react";
import { motion } from "motion/react"; // or "framer-motion"
import { BsRobot } from "react-icons/bs";
import { IoSparkles } from "react-icons/io5";
import { FcGoogle } from "react-icons/fc";
import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "../utils/firebase";
import { ServerUrl } from "../App";
import axios from "axios"
import { useDispatch } from "react-redux";
import { setUserData } from "../redux/userSlice";
function Auth({ isModel = false }) {
  const dispstch = useDispatch()
  const handleGoogleAuth = async () => {
  try {
    const response = await signInWithPopup(auth, provider);

    const user = response.user;

    const name = user.displayName;
    const email = user.email;
    

    

    const result = await axios.post(
      `${ServerUrl}/api/auth/google`,
      {
        name,
        email,
      },
      {
        withCredentials: true,
      }
    );
    dispstch(setUserData(result.data))

    

  } catch (error) {
    console.error("Auth Error:", error);
    dispstch(setUserData(null))

    if (error.response) {
      console.log(error.response.data);
    }
  }
};

  return (
    <div
      className={`w-full ${
        isModel
          ? "py-4"
          : "min-h-screen bg-[#f3f3f3] flex items-center justify-center px-6 py-20"
      }`}
    >
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className={`w-full ${
          isModel
            ? "max-w-md p-8 rounded-3xl"
            : "max-w-lg p-12 rounded-4xl"
        } bg-white shadow-2xl border border-gray-200`}
      >
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="bg-black text-white p-2 rounded-lg">
            <BsRobot size={18} />
          </div>
          <h2 className="font-semibold text-lg">InterviewIQ.AI</h2>
        </div>

        <h1 className="text-2xl md:text-3xl font-semibold text-center leading-snug mb-4">
          Continue with{" "}
          <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full inline-flex items-center gap-2">
            <IoSparkles size={16} />
            AI Smart Interview
          </span>
        </h1>

        <p className="text-gray-500 text-center mb-8">
          Sign in to start AI-powered mock interviews.
        </p>

        <motion.button
          onClick={handleGoogleAuth}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="w-full flex items-center justify-center gap-3 py-3 bg-black text-white rounded-full"
        >
          <FcGoogle size={20} />
          Continue with Google
        </motion.button>
      </motion.div>
    </div>
  );
}

export default Auth;